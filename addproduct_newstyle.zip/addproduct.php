<html>
	<head>
	  <title>PHP Test</title>	  
	  <link rel="stylesheet" type="text/css" href="style.css">
	 </head>
	 <body>
			 <div class="top-box">				 
			 <h1><span class="red">Sale</span><span class="blue">Project</span></h1>
			</div>

			 <div class="navbar">
			<ul class= nav>
			  <li><a href="#catalog">Catalog</a></li>
			  <li><a href="#yourproducts">Your Products</a></li>
			  <li><a class="active" ="#addcontact">Add Product</a></li>
			  <li><a href="#sales">Sales</a></li>
			  <li><a href="#purchase">Purchase</a></li>
			</ul>



			</div>

	 </body>

</html>


