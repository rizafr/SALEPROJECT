<html>
	<head>
	  <title>PHP Test</title>
	  
	  <link rel="stylesheet" type="text/css" href="style.css">
	 </head>
	 <body>
			 <div class="register-box">
				 
		 <h1><span class="red">Sale</span><span class="blue">Project</span></h1>
				 <h2>Please Register</h2>
				 <hr>
			 <form action="welcome.php" method="post">
				<label for="Fullname">Full Name</label>
				<input id="fullname" type="text" name="fullname"><br>
				
				<label for="username">Username</label>
				<input id="username" type="text" name="username"><br>

				<label for="email">E-mail</label>
				<input id="email" type="text" name="email"><br>

				<label for="password">Password</label>
				<input id="password" type="password" name="password"><br>


				<label for="conpassword">Confirm Password</label>
				<input id="conpassword" type="password" name="conpassword"><br>

				<label for="address">Full Address</label>
				<input id="address" type="text" name="address"><br>

				<label for="postalcode">Postal Code</label>
				<input id="email" type="text" name="email"><br>

				<label for="phone">Phone Number</label>
				<input id="phone" type="text" name="phone"><br>


				<input type="submit" value="REGISTER" />
			</form>
			<p>Already register? Login <a href="#">here</a></p>
			</div>
	 </body>

</html>
