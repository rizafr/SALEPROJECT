<html>
	<head>
	  <title>PHP Test</title>
	  
	  <link rel="stylesheet" type="text/css" href="style.css">
	 </head>
	 <body>
			 <div class="login-box">
				 
		 <h1><span class="red">Sale</span><span class="blue">Project</span></h1>
				 <h2>Please Login</h2>
				 <hr>
			 <form action="welcome.php" method="post">
				<label for="user">Email or Username</label>
				<input id="user" type="text" name="username"><br>
				
				<label for="password">Password</label>
				<input id="password" type="password" name="password"><br>
				<input type="submit" value="LOGIN" />
			</form>
			<p>Don't have an account yet? Register <a href="#">here</a></p>
			</div>
	 </body>

</html>
